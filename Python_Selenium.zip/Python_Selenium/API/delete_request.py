import requests

url = "https://jsonplaceholder.typicode.com/posts/101"

response = requests.delete(url)

if response.status_code == 200:
    print("Delete successful")
    print(response.json())
else:
    print(f"Delete unsuccessful, status code: {response.status_code}")