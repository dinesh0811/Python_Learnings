import requests
url = "https://www.linkedin.com/feed/"

response = requests.get(url)

if response.status_code == 200:
    print("Request was successful!")
    #print(response.json())
else:
    print("Request was unsuccessful, status code : ", response.status_code)

