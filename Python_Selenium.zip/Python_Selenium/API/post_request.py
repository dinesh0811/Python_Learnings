import requests

url = "https://jsonplaceholder.typicode.com/posts"

data = {
    'title': 'foo',
    'body': 'bar',
    'userId': 1
}
response = requests.post(url, json=data)

if response.status_code == 201:
    print("New data created")
    print(response.json())
else:
    print(f"New data creation failed, Status code: {response.status_code}")