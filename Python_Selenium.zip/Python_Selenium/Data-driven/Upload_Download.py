from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

file_path = "Users/Saaral/Downloads/download.xlsx"
driver = webdriver.Edge()
driver.maximize_window()
driver.implicitly_wait(5)
driver.get("https://rahulshettyacademy.com/upload-download-test/index.html")

driver.find_element(By.ID, "downloadButton").click()

fine_input = driver.find_element(By.ID, "fileinput")
fine_input.send_keys(file_path)

wait = WebDriverWait(driver, 10)
locator = (By.CSS_SELECTOR,"//div[@class='Toastify__toast-body']/div[2]")
wait.until(EC.visibility_of_element_located(locator))
print(driver.find_element(locator).text)