
import openpyxl as xl

book = xl.load_workbook("D:\\Python_Selenium\\Data-driven_files\\Python_demo.xlsx")
sheet = book.active

print(book.sheetnames)

Dict = {}
cell = sheet.cell(row=1, column=2)
print(cell.value)
sheet.cell(row=2, column=2).value = "Test01"
print(sheet.cell(row=2, column=2).value)
print(sheet.max_row)
print(sheet.max_column)
print(sheet["A3"].value)

for i in range(1, sheet.max_row+1): #to print all rows
    if sheet.cell(row=i,column=1).value == "Testcase2":
        for j in range(2, sheet.max_column+1): # to print all columns
            Dict[sheet.cell(row=1, column=j).value] = sheet.cell(row=i, column=j).value
print(Dict)

#to print 2nd sheet values
