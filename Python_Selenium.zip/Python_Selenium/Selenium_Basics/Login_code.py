import time

from selenium import webdriver
from selenium.webdriver.common.by import By

'''service_edge = Service("C/Users/Saaral/Downloads/edgedriver_win64/msedgedriver.exe")
driver = webdriver.Edge(service=service_edge)'''
driver = webdriver.Edge()
driver.maximize_window()
#driver.set_window_size(1024, 768)
#size = driver.get_window_size()
#print(size)
driver.get("https://www.facebook.com/")
"""driver.find_element(By.XPATH, "//div/input[@id='email']").send_keys("9626988462")
driver.find_element(By.XPATH, "//div/input[@id='pass']").send_keys("   ")"""
driver.execute_script("document.getElementById('email').value = '9626988462';")
driver.execute_script("document.getElementById('pass').value = 'dinesh01';")

login_button = driver.find_element(By.XPATH, "//button[@name='login']")
login_button.click()

driver.implicitly_wait(3)
print(driver.title)
#print(driver.current_url)
#print(driver.page_source)
#driver.back()
#driver.forward()
driver.refresh()
time.sleep(2)