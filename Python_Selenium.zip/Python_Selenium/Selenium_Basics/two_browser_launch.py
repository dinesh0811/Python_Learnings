import time

from selenium import webdriver

driver = webdriver.Edge()
driver.maximize_window()
driver.get("https://www.facebook.com/")
time.sleep(3)

print(driver.current_url)

window2 = webdriver.Chrome()
window2.maximize_window()
window2.get("https://www.google.com")
time.sleep(3)
print(driver.current_url)