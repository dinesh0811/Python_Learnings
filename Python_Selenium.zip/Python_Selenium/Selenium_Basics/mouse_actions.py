import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By

driver = webdriver.Edge()
driver.maximize_window()
driver.implicitly_wait(3)
driver.get("https://rahulshettyacademy.com/AutomationPractice/")

#mouse action
action = ActionChains(driver)
action.move_to_element(driver.find_element(By.ID, "mousehover")).perform()
# context_click() means right click
#action.context_click(driver.find_element(By.LINK_TEXT, "Top")).perform()
action.move_to_element(driver.find_element(By.LINK_TEXT, "Reload")).click().perform()
action.double_click(driver.find_element(By.XPATH, "//input[@value='radio1']")).perform()

time.sleep(2)
driver.quit()

