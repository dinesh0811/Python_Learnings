import time

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Edge()
driver.implicitly_wait(5)
name ="Test"
driver.maximize_window()
driver.get("https://rahulshettyacademy.com/AutomationPractice/")
driver.find_element(By.CSS_SELECTOR, "#name").send_keys(name)
driver.find_element(By.CSS_SELECTOR, "#alertbtn").click()
time.sleep(2)
#to accept the pop-up
alert = driver.switch_to.alert
assert name in alert.text
alert.accept()

#to accept the pop-up
driver.find_element(By.CSS_SELECTOR, "#name").send_keys(name)
driver.find_element(By.CSS_SELECTOR, "#confirmbtn").click()
time.sleep(2)
alert1 = driver.switch_to.alert
alert1.dismiss()



time.sleep(3)
driver.quit()