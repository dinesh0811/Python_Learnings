import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By

driver = webdriver.Edge()
driver.maximize_window()
driver.implicitly_wait(3)
driver.get("https://the-internet.herokuapp.com/windows")
mouse_click = ActionChains(driver)
mouse_click.click(driver.find_element(By.LINK_TEXT, "Click Here")).perform()

Windows_opened = driver.window_handles

driver.switch_to.window(Windows_opened[1])
print(driver.find_element(By.TAG_NAME, "h3").text)
# to close the 2nd window alone

driver.switch_to.window(Windows_opened[0])
assert "Opening a new window" == driver.find_element(By.TAG_NAME, "h3").text

#to close whole browser
time.sleep(3)
driver.quit()