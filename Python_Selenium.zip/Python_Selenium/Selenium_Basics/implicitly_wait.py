import time

from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Edge()
driver.maximize_window()
driver.get("https://rahulshettyacademy.com/seleniumPractise/#/")
# 5 seconds is max time out. If it loads in 2 seconds (3 seconds saves) and code starts it's action
driver.implicitly_wait(3)
driver.find_element(By.CSS_SELECTOR, ".search-keyword").send_keys("ber")
time.sleep(2)
results = driver.find_elements(By.XPATH, "//div[@class='product']")
assert len(results) > 0

for result in results:
    result.find_element(By.XPATH, "div/button").click()

driver.find_element(By.XPATH, "//img[@alt='Cart']").click()
driver.find_element(By.XPATH, "//button[text()='PROCEED TO CHECKOUT']").click()


driver.find_element(By.XPATH, "//input[@class='promoCode']").send_keys("rahulshettyacademy")
driver.find_element(By.XPATH, "//button[@class='promoBtn']").click()

time.sleep(8)
assert driver.find_element(By.CSS_SELECTOR, "span[class='promoInfo']").text == "Code applied ..!"

time.sleep(3)
driver.quit()