import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.maximize_window()
driver.implicitly_wait(5)
driver.get('https://the-internet.herokuapp.com/iframe')

"""One the famous interview question 
How will you handle frame and them how will you validate the value/text?"""
#To find the element/value in the frame, we need to switch to frame
driver.switch_to.frame("mce_0_ifr")
driver.find_element(By.CLASS_NAME, "tox-icon").click()

time.sleep(2)



driver.find_element(By.ID, "tinymce").clear()
driver.find_element(By.ID, "tinymce").send_keys("I am able to automate frames")

#Once our validation done we need to switch back or default page.
driver.switch_to.default_content()

assert "An iFrame containing the TinyMCE WYSIWYG Editor" == driver.find_element(By.TAG_NAME, "h3").text
time.sleep(2)
driver.close()