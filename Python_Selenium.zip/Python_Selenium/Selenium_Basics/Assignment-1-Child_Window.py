import time

from selenium import webdriver
from selenium.webdriver import ActionChains

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


driver = webdriver.Chrome()
driver.maximize_window()
driver.implicitly_wait(5)
driver.get('https://rahulshettyacademy.com/loginpagePractise/')

wait = WebDriverWait(driver, 10).until
wait(EC.presence_of_element_located((By.XPATH, "//a[@class='blinkingText'][1]"))).click()

New_window = driver.window_handles
driver.switch_to.window(New_window[1])

text = driver.find_element(By.XPATH, "//p[@class='im-para red']").text
mail_id = text.split(" ")
mail= mail_id[4]

driver.switch_to.window(New_window[0])
driver.find_element(By.ID, "username").send_keys(mail)
driver.find_element(By.ID, "password").send_keys("password")

radio_button = driver.find_element(By.XPATH, "//label[@class='customradio'][2]")
radio_button.click()

time.sleep(1)
actions = ActionChains(driver)
actions.move_to_element(wait(EC.presence_of_element_located((By.ID, "okayBtn")))).click().perform()


dropdowns = driver.find_elements(By.XPATH, "//select[@class='form-control']/option")
for dropdown in dropdowns:
    if dropdown.text == "Teacher":
        dropdown.click()
        break

driver.find_element(By.ID, "terms").click()
assert driver.find_element(By.ID, "terms").is_selected()

driver.find_element(By.ID, "signInBtn").click()

warning_message = wait(EC.presence_of_element_located
                  ((By.XPATH, "//div[@style='display: block;']"))).text
print(warning_message)
# assert "Incorrect" in text

time.sleep(2)
driver.quit()
