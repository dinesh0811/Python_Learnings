import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

driver = webdriver.Edge()
driver.maximize_window()
driver.implicitly_wait(3)
driver.get("https://rahulshettyacademy.com/seleniumPractise/#/")
driver.find_element(By.CSS_SELECTOR, ".search-keyword").send_keys("ber")
time.sleep(2)
results = driver.find_elements(By.XPATH, "//div[@class='product']")
assert len(results) > 0

#Assignment-2
expected_list = ["Cucumber - 1 Kg", "Raspberry - 1/4 Kg", "Strawberry - 1/4 Kg"]
actual_list = []

for result in results:
    actual_list.append(result.find_element(By.XPATH, "h4").text)
    result.find_element(By.XPATH, "div/button").click()

assert expected_list == actual_list

# .increment
driver.find_element(By.XPATH, "//img[@alt='Cart']").click()
driver.find_element(By.XPATH, "//button[text()='PROCEED TO CHECKOUT']").click()

#sum validation
prices = driver.find_elements(By.XPATH, "//td[5]/p[@class='amount']")
sum = 0
for price in prices:
    sum = sum + int(price.text)

assert sum == int(driver.find_element(By.CSS_SELECTOR, ".totAmt").text)

driver.find_element(By.XPATH, "//input[@class='promoCode']").send_keys("rahulshettyacademy")
driver.find_element(By.XPATH, "//button[@class='promoBtn']").click()

#Explicit wait
wait = WebDriverWait(driver, 10)
wait.until(expected_conditions.presence_of_element_located((By.CSS_SELECTOR, "span[class='promoInfo']")))

#Assignment-1 total amount > total amount discount
Discount_amt = float(driver.find_element(By.CSS_SELECTOR, ".discountAmt").text)
assert sum > Discount_amt

assert driver.find_element(By.CSS_SELECTOR, "span[class='promoInfo']").text == "Code applied ..!"

driver.quit()