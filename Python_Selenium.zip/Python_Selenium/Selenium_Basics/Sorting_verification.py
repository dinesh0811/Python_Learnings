import time

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Edge()
driver.maximize_window()
driver.implicitly_wait(3)
driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers/")

driver.find_element(By.XPATH, "//span[@class='sort-icon sort-ascending']").click()

time.sleep(2)
driver.close()