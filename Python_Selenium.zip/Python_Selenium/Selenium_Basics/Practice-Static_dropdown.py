import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select


driver = webdriver.Edge()
driver.maximize_window()
driver.get("https://rahulshettyacademy.com/angularpractice/")

driver.find_element(By.XPATH, "//div/input[@name='name']").send_keys("Test")
driver.find_element(By.XPATH, "//div/input[@name='email']").send_keys("hello@gmail.com")
driver.find_element(By.XPATH, "//div/input[@id='exampleInputPassword1']").send_keys("12345678")
time.sleep(2)
#Check-box
driver.find_element(By.XPATH, "//div/input[@id='exampleCheck1']").click()
time.sleep(3)
#Static drop-down and selecting by it's value
dropdown = Select(driver.find_element(By.XPATH, "//div/select[@id='exampleFormControlSelect1']"))
dropdown.select_by_visible_text("Female")
time.sleep(2)
#Selecting a radio button using fow loop
select_radiobutton = driver.find_elements(By.XPATH, "//div[@class='form-check form-check-inline']")
for radiobutton in select_radiobutton:
    if radiobutton.text == "Employed":
        radiobutton.click()
        break
time.sleep(3)

# Selecting birthday date
#driver.find_element(By.XPATH, "//input[@name='bday']")

driver.find_element(By.CSS_SELECTOR, "h4 input[name='name']").send_keys("Test01")

#Clicking submit button
driver.find_element(By.XPATH, "//input[@type='submit']").click()

driver.implicitly_wait(5)

validation_text = driver.find_element(By.CSS_SELECTOR, "div[ class='alert alert-success alert-dismissible']")
assert "Success!" in validation_text.text
time.sleep(10)
driver.quit()