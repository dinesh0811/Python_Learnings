"""Write a program that takes a list of numbers and returns the sum of the numbers.

Example:
Input: [1, 2, 3, 4]
Output: 10"""
def add_num(arr):
    #[1,2,3,4]
    return sum(arr)
print(add_num([1,2,3,4]))


"""Write a program that takes a number and checks whether it is even or odd.

Example:
Input: 5
Output: Odd"""

def find_odd(inp):
    if inp % 2 == 0:
        return "Even"
    else:
        return "Odd"
user_input = int(input("Enter a numeric input: "))
result = find_odd(user_input)
print(f"The number {user_input} is {result}")

"""Write a program that takes a list of numbers and returns the maximum number in the list.

Example:
Input: [10, 25, 50, 30]
Output: 50"""

def max_num(arr):
    return max(arr)
arr = [10, 25, 50, 30]
result = max_num(arr)
print(f"The maximum number is {result}")

"""Write a function that takes a number n and returns its factorial.

Example:
Input: 5
Output: 120 (because 5! = 5 * 4 * 3 * 2 * 1 = 120)"""
def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)
n = 5
result = factorial(n)
print(f"The factorial of {n} is {result}")

"""Count Vowels:
Write a program that takes a string and counts the number of vowels in it.

Example:
Input: "hello world"
Output: 3 (vowels: 'e', 'o', 'o')"""
def count_vowels(v):
    vowels = "aeiouAEIOU"
    count = 0
    for char in v:
        if char in vowels:
            count += 1
    return count
v = "Hello World"
result = count_vowels(v)
print(f"The number of vowels in {v} is {result}")


"""
Reverse a String:
Write a program that reverses a given string.

Example:
Input: "Python"
Output: "nohtyP"""
def reverse_string(s):
    return s[::-1]

s = "Python"
print(reverse_string(s))

"""
Fibonacci Sequence:
Write a program that generates the first n numbers of the Fibonacci sequence.

Example:
Input: 5
Output: [0, 1, 1, 2, 3]
"""
def fibonacci(n):
    fib_sequence = []
    a, b = 0, 1
    for _ in range(n):
        fib_sequence.append(a)
        a, b = b, a + b
    return fib_sequence

# Example usage:
n = 10
result = fibonacci(n)
print(f"The first {n} numbers in the Fibonacci sequence are: {result}")

"""
Palindrome Check:
Write a program that checks if a given string is a palindrome (reads the same forwards and backwards).

Example:
Input: "madam"
Output: True
"""
def palindrome(p):
    p = p.replace(" ", "").lower()

    return p == p[::1]
p = "madam"
result1 = palindrome(p)
print(f"Is {p} a palindrome?\n{result1}")

a = "A man a plan a canal Panama"
result2 = palindrome(a)
print(f"Is {a} a palindrome?\n{result2}")

"""
Prime Number Check:
Write a function that checks if a number is prime or not.

Example:
Input: 7
Output: True
"""
def prime_check(number):
    number = int(number.replace(",",""))
    if number <= 1:
        return False
    for i in range(2, number):
        if number % i == 0:
            return False
    return True
try:
    number = input("Enter a number: ")
    result = prime_check(number)
    print(f"Is {number} a prime number? {result}")
except Exception as e:
    print(f"An Error occurred: {e}")

"""
Remove Duplicates:
Write a program that removes duplicates from a list.

Example:
Input: [1, 2, 3, 1, 2, 4]
Output: [1, 2, 3, 4]"""

def remove_duplicates(lst):
    result = []
    for item in lst:
        if item not in result:
            result.append(item)
    return result
lst = [1, 2, 3, 1, 2, 4]
print(f"List after removing all duplicate is {remove_duplicates(lst)}")