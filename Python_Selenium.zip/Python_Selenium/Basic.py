def ArrayAdditionI(arr):
    largest = max(arr)

    arr.remove(largest)
    list1 = []
    for i in arr:
        list1.append(i)
    print(list1)

ArrayAdditionI([4, 6, 23, 10, 1, 3])

def ArrayAdditionL(ar):
    n = len(ar)
    ar.sort()
    for i in range (n - 2, -1, -1):
        if ar[i] != ar[n-1]:
            return ar[i]
    return -1
if __name__ == "__main__":
    ar = [10, 2, 5, 9, 4, 7, 10]
    print(ArrayAdditionL(ar))