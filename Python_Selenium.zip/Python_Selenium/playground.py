def prime_check(number):
    #number = int(number.replace(",",""))
    for i in range(2, number):
        if number % i == 0:
            return False
    return True
number = input("Enter a Number: ")
try:
    result = prime_check(int(number))
    print(f"Is {number} a prime number?\n{result}")
except Exception as e:
    print(f"An Error occurred: {e}")