class Shark:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def swim(self):
        # Reference the name
        print(self.name + " is swimming.")

    def be_awesome(self):
        # Reference the name
        print(self.name + " is being awesome.")
def main():
    sammy = Shark("Sammy", 10)
    sammy.swim()
    storm = Shark("Storm", 7)
    storm.be_awesome()

if __name__ == "__main__":
    main()