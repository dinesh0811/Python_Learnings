class Fish:
    def __init__(self, first_name, last_name="Fish", skeleton="bone", eyelids=False):
        self.first_name = first_name
        self.last_name = last_name
        self.skeleton = skeleton
        self.eyelids = eyelids

    def swim(self):
        print("This fish is swimming")
    def backword_swim(self):
        print("This fish can swim backwords")

class GoldFish(Fish):
    def __init__(self, water = "freshwater"):
        self.water = water
        super().__init__(self)
# Initiates first name
fish1 = GoldFish()
fish1.first_name = "Gold"
#User parent __init__ through super()
print(fish1.first_name + " " + fish1.last_name)
print(fish1.eyelids)

#User child __init__override
print(fish1.water)

#Use parent swim method
fish1.swim()

class ClownFish(Fish):
    def live_with_anmeone(self):
        print("This clowFish is coexisting with another fish")

dory = ClownFish("Dory")
print(dory.first_name + " " + dory.last_name)
dory.swim()
dory.live_with_anmeone()

class Shark(Fish):
    def __init__(self,first_name, last_name = "Shark", skeleton="cartilage", eyelids=True):
        self.first_name = first_name
        self.last_name = last_name
        self.skeleton = skeleton
        self.eyelids = eyelids
    def backword_swim(self):
        print("The Shark cannot swim backwards, but can shin backwards")
fish1 = Shark("Nemo")
print(fish1.first_name + " " + fish1.last_name)
fish1.swim()
fish1.backword_swim()
print(fish1.skeleton)
print(fish1.eyelids)

