class Shark1:
    # Class variables
    animal_type = "fish"
    location = "ocean"

    def __init__(self, name, age):
        self.name = name
        self.age = age
    #method with instance variable followers
    def set_followers(self, followers):
        print("The user has " + str(followers) + " followers")

def main():
    #First object, set instance variable of constructor method
    sammy = Shark1("Sammy", 12)
    #print out the instance of the variable
    print(sammy.name)
    #print out the class variable location
    print(sammy.location)
    #second object
    storm = Shark1("Storm", 10)
    # print out the instance variable name
    print(storm.name)
    #user set followers method and pass followers instance variable
    storm.set_followers(50)
    # print out the class variable animal type
    print(storm.animal_type)

if __name__ == "__main__":
    main()