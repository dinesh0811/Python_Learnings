import time
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Edge()
driver.implicitly_wait(3)
driver.maximize_window()

driver. get("https://uat-frontend.enrichmoney.in:3008/authentication/login")

driver.find_element(By.CSS_SELECTOR, "#inp").send_keys("E042")
driver.find_element(By.XPATH, "//input[@type='password']").send_keys("Enrich@16")

time.sleep(1)
driver.find_element(By.XPATH, "//button[normalize-space()='Continue']").click()

time.sleep(2)
driver.find_element(By.XPATH, "//input[@id='otp_box']").send_keys("2000")
time.sleep(1)

driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()

time.sleep(10)

driver.close()
