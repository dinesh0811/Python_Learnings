import time
from selenium import webdriver
from selenium.webdriver.common.by import By

#Headless mode (without opening the browser)
chrome_option = webdriver.ChromeOptions()
chrome_option.add_argument("headless")

# To click advance and proceed (to handle certificate errors)
chrome_option.add_argument("--ignore-certificate-errors")

driver = webdriver.Chrome(options=chrome_option)
driver.maximize_window()
driver.implicitly_wait(2)

driver.get('https://rahulshettyacademy.com/AutomationPractice/')

# To scroll down to the given page we can use js using below method.
""" To scroll down user below command
window.scrollTo(0,500)
Here x axis 0, y axis 500"""
#driver.execute_script("window.scrollTo(0,500);")

# To scroll bottom of the page
driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")

time.sleep(1)
# Taking screenshots
driver.get_screenshot_as_file("Screenshot.png")
#driver.save_screenshot("SS.png")

time.sleep(1)
driver.close()
