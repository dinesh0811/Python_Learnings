import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.maximize_window()
driver.implicitly_wait(3)
driver.get("https://www.lambdatest.com/selenium-playground/table-sort-search-demo")

value = "New York"
total_sum = 0

try:
    @pytest.mark.functional
    def test_find_element():
        total_entries = driver.find_elements(By.XPATH, "//tr/td[1]")
        return len(total_entries)

    total_pages = driver.find_elements(By.XPATH, "//span/a")
    for j in range(len(total_pages)):
        if j == 0:
            pass
        else:
            driver.find_element(By.ID, "example_next").click()
        total_sum = total_sum + test_find_element()
    assert total_sum == 24
    print("Verified 24 entries are there in the table")

    # Entering "New York" in the Search box
    driver.find_element(By.XPATH, "//input[@type='search']").send_keys(value)
    # Explicit wait
    WebDriverWait(driver, 5).until(EC.visibility_of_element_located((By.XPATH, "//tr/td[1]")))
    # Validation
    new_sum = test_find_element()
    assert new_sum == 5
    print("Verified that 5 entries listed out of 24 total entries")

except Exception as e:
    print(f"An error Occurred: {e}")