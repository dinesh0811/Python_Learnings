# code
puts "Hello World"

# variable
character_name = "Jhon"
character_age = "30"
puts ("It's day 1 and I am " + character_name)
puts ("I am " + character_age + " years old.")
character_name = "Tom"
puts ("He realy liked the name " + character_name)
puts ("But he didn't like being " + character_age)

# Datatypes
name = "Tom" #String
age = 30 #int
gpa = 2.8 #float
ismale = true #bool
istall = false #bool
flip = nil #nil

#String 
topic = "Ruby\'s language"
puts topic
topic = "Ruby\nlanguage" # next line
puts topic
topic = "Ruby language" # Uppercase
puts topic.upcase()
topic = "Ruby language" # Lowercase
puts topic.downcase()
topic = "           Ruby language         " # Removing white space
puts topic.strip()
topic = "Ruby language" # length of the word
puts topic.length()
topic = "Ruby language" # finding matching word
puts topic.include? "lan"
topic = "Ruby language" # Find the letter
puts topic[0]
topic = "Ruby language" # Find the letter
puts topic[0,4]
topic = "Ruby language" # Find the letter
puts topic[-1]
topic = "Ruby language" # Find the index of the letter
puts topic.index("l")

#Math and Numbers
puts 5 + 10 # addition
puts 2**3 # Power 
puts 10 % 3 # reminder
num = 10
puts ("my fav num is " + num.to_s) #Here '.to_s'is used to change the int value into string
puts num.abs() # To print absolute value
num1 = 10.55
puts num1.round() # To generate round value in int formate
puts Math.sqrt(25) # Finding the sqrt for given number using math class
puts Math.log(1) # Finding the log 1 value
puts 10 / 7.0

#User Input
puts "Enter your name: "
name = gets.chomp()
puts "Enter your age: "
age = gets.chomp() # Input, and using chomp() for printing all values in same line
puts ("Hello " + name + ", you are " + age)

# Building a basic calculator
puts "Enter a number: "
num1 = gets.chomp()
puts "Enter another number: "
num2 = gets.chomp()

puts (num1.to_i + num2.to_i) # Here ".to_i" used to update the value into int
puts (num1.to_f + num2.to_f) # Here ".to_f" used to update the value into float

# Mad lib games
#Whenever we using input use terminal to run the code
puts "Enter a name: "
name = gets.chomp()
puts "Enter a plural_noun: "
plural_noun = gets.chomp()
puts "Enter a celebrity: "
celebrity = gets.chomp()

puts ("Roses are " + name)
puts (plural_noun + " are blue")
puts ("I love " + celebrity)

# Array
friends = Array["Adam", "Bala", "Tim", "Jerry"]
friends[0] = "Arun"
puts friends[0]
puts friends[-1]
puts friends[0, 2]
puts friends.length()
puts friends.include? "Bala"
puts friends.reverse() 
puts friends.sort()
# We can't sort if we have different datatypes ["String", 10]

# Hashes (Key/Value pair)
states = { :Tamilnadu => "TN",
"Karnataka" => "KN",
"Karala" => "KL"
}
puts states[:Tamilnadu]
puts states["Karala"]

#Methods
def sayhi
  puts "Hello World"
end

puts "Top"
sayhi
puts "Bottom"

def sayhi(name, age)
  puts ("Hello " + name + ", you are " + age.to_s)
end

sayhi("Tim", 10)

def sayhi(name ="No name", age = -1)
  puts ("Hello " + name + ", you are " + age.to_s)
end

sayhi #Default value

# Return types
def cube(num)
  return num**3 # when we use return keyword the function will stop on return and will not run upcoming lines.
  puts "Hello"
end
puts cube(5)

def cube(num)
  return num**3, 10 
end
puts cube(5) # to print the available values inside the return function
puts cube(5) [1] # To print the index

# If statements
ismale = true
istall = true

if ismale and istall
    puts "You are a tall male"
elsif ismale and !istall
    puts "You are a short male"
elsif !ismale and istall
    puts "You are not male but are tall"
else 
    puts "You are not male and tall"
end

def max(num1, num2, num3)
  if num1 >= num2 and num1 >= num3
      return num1
  elsif num2 >= num1 and num2 >= num3
      return num2
  else 
      return num3
  end
end
puts max(100,20,3)

# Buildin a good calculator
puts "Enter 1st number: "
num1 = gets.chomp().to_f
puts "Enter operator: "
op = gets.chomp()
puts "Enter 2nd number: "
num2 = gets.chomp().to_f

if op == "+"
    puts (num1 + num2)
elsif op == "-"
    puts (num1 - num2)
elsif op == "*"
    puts (num1 * num2)
elsif op == "/"
    puts (num1/num2)
else
    puts "Invalid Operator"
end

# case expression (we can use it insted of if conditions)
def get_day_name(day)
  day_name = ""
  case day
  when "sun"
      day_name = "Sunday"
  when "mon"
      day_name = "Monday"
  when "tue"
      day_name = "Tuesday"
  when "wed"
      day_name = "Wednesday"
  when "thu"
      day_name = "Thursday"
  when "fri"
      day_name = "Friday"
  when "sat"
      day_name = "Saturday"
  else
      day_name = "Invalida abbreivation"
  end

  return day_name
end

puts get_day_name("sun")

# While loop
index = 1
while index <= 5
    puts index
    index += 1

end

# Builing a guessing game
secret_word = "Tom"
guess = ""

while guess != secret_word
    print "Enter guess: "
    guess = gets.chomp()
end
puts "You Won!"

secret_word = "Tom"
guess = ""
guess_count = 0
guess_limit = 3
out_of_guesses = false

while guess != secret_word and !out_of_guesses
    if guess_count < guess_limit
        print "Enter guess: "
        guess = gets.chomp()
        guess_count += 1
    else
        out_of_guesses = true
    end
end

if out_of_guesses
    puts "You Lose!"
else
    puts "You Won!"
end

# For loop
friends = ["Adam", "Bala", "Canva", "Jerry"]
# To print all names in the arr
for friend in friends
    puts friend
end
# To print all names in the arr (Another method)
friends.each do |fri|
    puts fri
end
# To print number from 0 to 5
for index in 0..5
    puts index
end
# To print number from 0 to 5 (Another method)
6.times do |num|
    puts num
end

# Exponent Method
# For loop type-1
def pow(base_num, pow_num)
    result = 1
    pow_num.times do 
        result = result * base_num
    end
    return result 
end
puts pow(5, 3)

# For loop type-2
def pow(base_num, pow_num)
    result = 1
    for i in 1..pow_num
        result = result * base_num
    end
    return result 
end
puts pow(5, 3)

# Reading files
File.open("Readme.txt", "r") do |file|
    #puts file.read().include? "Adam"
    # To ready a line
    #puts file.readlines()[0]
    # For loop
    for line in file.readlines()
        puts line
    end
end

# To ready and close
file = File.open("Readme.txt", "r")
puts file.read
file.close()

# Writting Files
=begin
r - Read
r+ -  Read and Write
rb - Read-only binary 
w - Write only (creates a new file)
wb - Write in binary mode
a - append 
=end

# Add a new line using append mode 
file = File.open("Readme.txt", "a") do |file|
    file.write("\nTom, HR") #\n for adding it in new line
end
# Using w to create a new file 
file = File.open("Readme.html", "w") do |file|
    file.write("<h1>Hello<h1>") 
end

# r+ used to update a line 
File.open("Readme.txt", "r+") do |file|
    file.readline()
    file.write("Hi") 
end

# Exception Handling
num = 10/0 #Zerodivision error

numbers = [1, 4, 8, 20, 45, 62]
numbers["Dog"] #Type error

#Zerodivision error
numbers = [1, 4, 8, 20, 45, 62]

begin
    num = 10/0 
    #Type error
    #numbers[100] 
rescue ZeroDivisionError => e
    puts "Division by zero error"
rescue TypeError => e
    puts "Type error"
rescue 
else 
    puts "No error occurred"
ensure
    puts "This will always executed"
end

#To handle all types of errors use rescue => e
numbers = [1, 4, 8, 20, 45, 62]
begin 
    numbers["abc"]
rescue => e
    puts "An error occurred: #{e.message}"

end

# Classes and Objects

class Book
    attr_accessor :title, :author, :pages
end
begin 
    #Instance of the class
    book1 = Book.new()
    book1.title = "English"
    book1.author = "Jerry"
    book1.pages = 350
    
    book2 = Book.new
    book2.title = "Tamil"
    book2.author = "Tom"
    book2.pages = 350

    # Accessing the attributes
    puts book1.title
    puts book2.author
rescue => e
    puts "An error occurred: #{e.message}"
end

# Initialize method

class Book
    attr_accessor :title, :author, :pages
    def initialize (title, author, pages)
        # Creating attribute
        @title = title
        @author = author
        @pages = pages
    end
end

begin 
    book1 = Book.new("English", "Jerry", 350)
    book2 = Book.new("Tamil", "Tom", 350)

    puts book1.title
    puts book2.author
rescue => e
    puts "An error occurred: #{e.message}"
end
=begin 
initialize is a built-in, predefined method name in Ruby, and changing its spelling breaks the code because Ruby doesn't know how to use a method that's not recognized.
=end

# Object methods
class Student
    attr_accessor :name, :major, :cgpa
    def initialize (name, major, cgpa)
        # Creating attribute
        @name = name
        @major = major
        @cgpa = cgpa
    end
    def has_honors
        if @cgpa >= 7.5
            return true
        end
        return false
    end
end

begin 
    student1 = Student.new("Tim", "Science", 6.9)
    student2 = Student.new("Tom", "English", 7.8)

    puts student1.has_honors
    puts student2.has_honors
rescue => e
    puts "An error occurred: #{e.message}"
end

# Building a quiz
class Question
    attr_accessor :prompt, :answer
    # Creating funtion
    def initialize(prompt, answer)
        # variable
        @prompt = prompt
        @answer = answer
    end
end
# questions
q1 = "What color are apples?\n(a)red\n(b)blue\n(c)yellow"
q2 = "How many tyres are there in car?\n(a)two\n(b)three\n(c)one\n(d)four"
q3 = "What color are bananas?\n(a)one\n(b)orange\n(c)yellow\n(d)green\n(e)violet"
# calling class to find the variables
questions = [
    Question.new(q1, "a"),
    Question.new(q2, "d"),
    Question.new(q3, "c")
]
# Creating a begin, resuce block to run the code
begin
    def run_quiz(questions)
        answer = ""
        score = 0
        for question in questions
            puts question.prompt
            # Getting i/p from the user 
            answer = gets.chomp()
            if answer == question.answer
                score += 1
            end
        end
        # Printing the result
        puts ("You got " + score.to_s + "/" + questions.length().to_s)
    end

    run_quiz(questions)   
rescue => e
    # using this block to find the error
    puts "An error occurred: #{e.message}"
end

# Inheritance and Mehod Overriding
# Creating a super class
class Chef
    # Method 1
    def make_chicken
        puts "The chef makes chicken"
    end
    # Method 2
    def make_salad
        puts "The chef makes salad"
    end
    # Method 3
    def make_special_dish
        puts "The chef makes Barbeque dish"
    end
end

# Creating new sub class to 'inherit' from the super class
class IndianChef < Chef
    # Method overriding (updating existing functionality for the new requirement)
    def make_special_dish
        puts "The Inidan chef makes Briyani dish"
    end
    # Method 2.1 
    def make_meal
        puts "The Inidan chef makes meal dish"
    end


end

begin
    chef = Chef.new()
    chef.make_special_dish

    chefind = IndianChef.new()
    chefind.make_special_dish
    chefind.make_meal
rescue => e
    puts "An error occurred: #{e.message}"
end

# Modules 
# If we want to use all availabel options in the 'useful_tool.rb' file use below method
require_relative "useful_tool.rb"

include Tools

Tools.sayhi("Tom")

