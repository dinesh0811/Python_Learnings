Adam, Salse
Bala, QA
Canva, Dev
Jerry, Manager
Tom, HR