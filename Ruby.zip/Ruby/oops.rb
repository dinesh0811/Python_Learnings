# Classes and object
class Dog
  # method 1
  def initialize(name, bread)
      @name = name
      @bread = bread
  end
  # method 2
  def bark 
      puts "#{@name} say woof!"
  end
end
# Asigning value to the variables
dog1 = Dog.new("Buddy", "Golden Retriever")
dog2 = Dog.new("Max", "Bulldog")

begin
  #calling the function
  dog1.bark
  dog2.bark

rescue => e
  # If any exception occurred it'll run
  puts "An exception orrurred: #{e.message}"
end

#------------------------------------------------------------------------------------
# Encapsulation

class Account
  def initialize(balance)
      @balance = balance # Encapsulated instance variable
  end

  def deposit(amount)
      @balance += amount
  end

  def withdraw(amount)
      if @balance >= amount
          @balance -= amount
      else 
          puts "Insufficient funds!"
      end
  end

  def display_balance
      puts "Current balance: #{@balance}"
  end
end

begin
  account = Account.new(1000)
  account.deposit(1000)
  account.withdraw(500)
  account.display_balance

rescue => e
  puts "Error occurred: #{e.message}"

end
#------------------------------------------------------------------------------------

# Inheritance

# Parent calss 
class Animal
  def speak
      puts "Animal speaks"
  end
end
# Child class 1 inherits from Aminal
class Dog < Animal
  def speak
      puts "woof!"
  end
end
# Child class 2 inherits from Aminal
class Cat < Animal
  def speak
      puts "meow!"
  end
end

dog = Dog.new()
cat = Cat.new()

begin
  dog.speak
  cat.speak
rescue => e
  puts "Error occurred: #{e.message}"
end
#------------------------------------------------------------------------------------

# Polymorphism
class Bird
  def speak
      puts "koo!"
  end
end

class Dog
  def speak
      puts "woof!"
  end
end

# Polymorphism 
begin
  def make_sound(animal)
      animal.speak
  end
  
  bird = Bird.new()
  dog = Dog.new()

  make_sound(bird)
  make_sound(dog)
rescue => e
  puts "Error occurred: #{e.message}"
end
#------------------------------------------------------------------------------------

# Abstraction
class Vehicle
  def start_engine
      reise NotImplementedError, 'Subclass must implement this method'
  end
end

class Car < Vehicle
  def start_engine
      puts "Car engine started!"
  end
end

class Bike < Vehicle
  def start_engine
      puts "Bike engine started!"
  end
end

car = Car.new()
bike = Bike.new()

begin
  car.start_engine
  bike.start_engine
rescue => e
  puts "Error occurred : "
end