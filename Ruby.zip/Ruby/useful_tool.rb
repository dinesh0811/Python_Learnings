# Creating a module
module Tools
  # Method 1
  def sayhi(name)
    puts "hello #{name}"
  end
  # Method 2
  def saybye(name)
    puts "bye #{name}"
  end
end

=begin
# Calling tools module
include Tools
# Accessing the methods inside module
Tools.sayhi("Tim")
Tools.saybye("Tim")
=end